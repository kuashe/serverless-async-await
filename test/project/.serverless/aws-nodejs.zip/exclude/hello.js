function hello()
{
    return 'hello'
}
module.exports.hello = hello